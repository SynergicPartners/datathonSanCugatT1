package com.example.fontsaiguaexample;

import java.util.ArrayList;
import java.util.List;

import android.app.Activity;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.os.Bundle;
import android.os.StrictMode;
import android.view.View;
import android.widget.ImageButton;
import android.widget.ImageView;
import android.widget.Toast;

import com.google.android.gms.maps.CameraUpdateFactory;
import com.google.android.gms.maps.GoogleMap;
import com.google.android.gms.maps.MapFragment;
import com.google.android.gms.maps.model.BitmapDescriptor;
import com.google.android.gms.maps.model.BitmapDescriptorFactory;
import com.google.android.gms.maps.model.LatLng;
import com.google.android.gms.maps.model.Marker;
import com.google.android.gms.maps.model.MarkerOptions;

public class MainActivity extends Activity {
	
	private List<Marker> ContenedoresMarkerList = new ArrayList<Marker>();
	private List<Marker> Camion1MarkerList = new ArrayList<Marker>();
	private List<Marker> Camion2MarkerList = new ArrayList<Marker>();
	private GoogleMap map;
	private static final LatLng SANTCUGAT = new LatLng(41.4667, 2.0833);
	private String[] latitud, longitud, numcontenedores, tipocontenedores, coef;
	private String[] lat1, lat2, long1, long2;
	private boolean ContenedoresIsMarked = false;
	private boolean Camion1IsMarked= false;
	private boolean Camion2IsMarked=false;
	private ImageButton gps,camion,contenedor,foto, perfil;
	private ImageView imatge1;

	private ImageView ivThumbnailPhoto;
	private Bitmap bitMap;

	@Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        perfil=(ImageButton)findViewById(R.id.ImageButton02);
        gps=(ImageButton)findViewById(R.id.BotoOpcio1);
		camion=(ImageButton)findViewById(R.id.BotoOpcio2);
		contenedor=(ImageButton)findViewById(R.id.BotoOpcio3);
		foto=(ImageButton)findViewById(R.id.BotoOpcio4);
		
        StrictMode.ThreadPolicy policy = new StrictMode.ThreadPolicy.Builder().permitAll().build();
        StrictMode.setThreadPolicy(policy); 
        
        map = ((MapFragment) getFragmentManager().findFragmentById(R.id.map))
                .getMap();
        map.moveCamera(CameraUpdateFactory.newLatLngZoom(SANTCUGAT, 13));
        map.setMyLocationEnabled(true);
        
        CreateArrayContenedores();
        CreateArrayCamiones();
        
        gps.setOnClickListener(new View.OnClickListener() {
			@Override
			public void onClick(View v) {
				}
		});
        
        perfil.setOnClickListener(new View.OnClickListener() {
			@Override
			public void onClick(View v) {
				Intent intent = new Intent(MainActivity.this, UserActivity.class);
				startActivityForResult(intent, 1);
				}
		});
        
        camion.setOnClickListener(new View.OnClickListener() {
			@Override
			public void onClick(View v) {
				if(Camion1IsMarked==false &&Camion2IsMarked==false){
					PintaCamiones(true);
            	}     	
            	else {
            		PintaCamiones(false);
            	}	
				
				}
		});
        
        contenedor.setOnClickListener(new View.OnClickListener() {
        	@Override
			public void onClick(View v) {
				// TODO Auto-generated method stub
				if(ContenedoresIsMarked==false){
            		PintaContenedores(true);
            	}     	
            	else {
            		PintaContenedores(false);
            	}
			}
		});
        
        foto.setOnClickListener(new View.OnClickListener() {
			@Override
			public void onClick(View v) {
				if(hasCamera()){
			/*	// create intent with ACTION_IMAGE_CAPTURE action 
		        Intent intent = new Intent(MediaStore.ACTION_IMAGE_CAPTURE);
		        // start camera activity
		        startActivityForResult(intent, TAKE_PICTURE);
				}*/
				Intent intent = new Intent(MainActivity.this, PhotoActivity.class);
				startActivityForResult(intent, 0);
				}
				else return;
				}

		/*	private void startActivityforResult(Intent intent, 1) {
				// TODO Auto-generated method stub
				
			}*/
        });

    }
	
	/*
	 * Las siguientes dos funciones han sido desarrolladas de forma manual como ejemplificaci�n.
	 * En un caso de implementaci�n real se tendria que hacer una funcion para crear las 
	 * imagenes de los camiones dependiendo de el n�mero de se�ales que lleguen de los transponders
	 * y recrear su posicion en el mapa, para esto seria necesario crear un int que podria ser 
	 * el id de los camiones e irlo concatenando a los strings que conforman la informaci�n necesarea
	 * para el seguimiento del veh�culo. En lugar de variables individuales usar vectores o listas.
	 */
	
	private void CreateArrayCamiones(){
		lat1 = getResources().getStringArray(R.array.LatCamion1);
		long1 = getResources().getStringArray(R.array.LongCamion1);
		lat2 = getResources().getStringArray(R.array.LatCamion2);
		long2 = getResources().getStringArray(R.array.LongCamion2);
		
		Marker marker,marker2;
   	 marker = map.addMarker(new MarkerOptions()
        .position(new LatLng(Double.parseDouble(lat1[1]),Double.parseDouble(long1[1])))
        .icon(BitmapDescriptorFactory
       .fromResource((R.drawable.img_timecar))));
   	marker.setVisible(false);
   	 marker2 = map.addMarker(new MarkerOptions()
        .position(new LatLng(Double.parseDouble(lat2[1]),Double.parseDouble(long2[1])))
        .icon(BitmapDescriptorFactory
       .fromResource((R.drawable.img_timecar))));
   	marker2.setVisible(false);
  	Camion1MarkerList.add(marker);
  	Camion2MarkerList.add(marker2);

	}
	
	private void PintaCamiones(boolean opcio){
		if(opcio==true){
    		for (int i=0; i<Camion1MarkerList.size();i++){
    			Camion1MarkerList.get(i).setVisible(true);
    		}
    		Camion1IsMarked=true;
    		for (int i=0; i<Camion2MarkerList.size();i++){
    			Camion2MarkerList.get(i).setVisible(true);
    		}
    		Camion2IsMarked=true;
    	}
    	
    	else{
    		for (int i=0; i<Camion1MarkerList.size();i++){
    			Camion1MarkerList.get(i).setVisible(false);
    		}
    		Camion1IsMarked=false;
    		for (int i=0; i<Camion2MarkerList.size();i++){
    			Camion2MarkerList.get(i).setVisible(false);
    		}
    		Camion2IsMarked=false;
    	}
		              
        
	}
	private void CreateArrayContenedores(){
    	latitud = getResources().getStringArray(R.array.LatitudesContenedores);
        longitud = getResources().getStringArray(R.array.LongitudesContenedores);
        numcontenedores = getResources().getStringArray(R.array.NumContenedores);
        tipocontenedores =  getResources().getStringArray(R.array.TipoContenedores);
        coef =  getResources().getStringArray(R.array.CoefContenedores);
        Marker marker;
                for(int i=0; i<latitud.length;i++){
                	if(Double.parseDouble(numcontenedores[i])==0){
                	marker = map.addMarker(new MarkerOptions()
                            .position(new LatLng(Double.parseDouble(latitud[i]),Double.parseDouble(longitud[i])))
                            .title(tipocontenedores[i])
                            .snippet(coef[i])
                            .icon(BitmapDescriptorFactory
                            .defaultMarker(BitmapDescriptorFactory.HUE_CYAN)));
                  	marker.setVisible(false);
                  	ContenedoresMarkerList.add(marker);
                	}
                	else if (Double.parseDouble(numcontenedores[i])==1){
                    	marker = map.addMarker(new MarkerOptions()
                    		.position(new LatLng(Double.parseDouble(latitud[i]),Double.parseDouble(longitud[i])))
                    		.title(tipocontenedores[i])
                    		.snippet(coef[i])
                    		.icon(BitmapDescriptorFactory
                    		.defaultMarker(BitmapDescriptorFactory.HUE_GREEN)));
                    	marker.setVisible(false);
                    ContenedoresMarkerList.add(marker);
                	}
                	else if (Double.parseDouble(numcontenedores[i])==2){
                    	marker = map.addMarker(new MarkerOptions()
                    		.position(new LatLng(Double.parseDouble(latitud[i]),Double.parseDouble(longitud[i])))
                        	.title(tipocontenedores[i])
                        	.snippet(coef[i])
                    		.icon(BitmapDescriptorFactory
                        	.defaultMarker(BitmapDescriptorFactory.HUE_YELLOW)));
                    	marker.setVisible(false);
                    ContenedoresMarkerList.add(marker);
                	}
                	else if(Double.parseDouble(numcontenedores[i])==3){
                    	marker = map.addMarker(new MarkerOptions()
                    		.position(new LatLng(Double.parseDouble(latitud[i]),Double.parseDouble(longitud[i])))
                    		.title(tipocontenedores[i])
                    		.snippet(coef[i])
                    		.icon(BitmapDescriptorFactory
                    		.defaultMarker(BitmapDescriptorFactory.HUE_ORANGE)));
                    	marker.setVisible(false);
                    ContenedoresMarkerList.add(marker);
            	}
                	else {
                    	marker = map.addMarker(new MarkerOptions()
                        	.position(new LatLng(Double.parseDouble(latitud[i]),Double.parseDouble(longitud[i])))
                        	.title(tipocontenedores[i])
                        	.snippet(coef[i])
                        	.icon(BitmapDescriptorFactory
                        	.defaultMarker(BitmapDescriptorFactory.HUE_RED)));
                    	marker.setVisible(false);
                    ContenedoresMarkerList.add(marker);
                	}
                }
    }
	
	
	private void PintaContenedores(boolean opcio){
    	if(opcio==true){
    		for (int i=0; i<ContenedoresMarkerList.size();i++){
    			ContenedoresMarkerList.get(i).setVisible(true);
    		}
    		ContenedoresIsMarked=true;
    	}
    	
    	else{
    		for (int i=0; i<ContenedoresMarkerList.size();i++){
    			ContenedoresMarkerList.get(i).setVisible(false);
    		}
    		ContenedoresIsMarked=false;
    	}
    }
	
	

	@Override
    protected void onActivityResult(int requestCode, int resultCode, Intent intent) {
		 if (requestCode == 0){
			 Toast.makeText(MainActivity.this, "�Has sumado 5 puntos!", Toast.LENGTH_SHORT).show();
		 }
		 super.onActivityResult(requestCode, resultCode, intent);
    	
        }
        
	 // method to check if you have a Camera
    private boolean hasCamera(){
        return getPackageManager().hasSystemFeature(PackageManager.FEATURE_CAMERA);
    }
}
