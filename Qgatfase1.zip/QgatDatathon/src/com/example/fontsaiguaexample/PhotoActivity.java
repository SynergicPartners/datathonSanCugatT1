package com.example.fontsaiguaexample;

import android.app.Activity;
import android.content.Intent;
import android.graphics.Bitmap;
import android.net.Uri;
import android.os.Bundle;
import android.provider.MediaStore;
import android.provider.MediaStore.Images;
import android.widget.Button;
import android.widget.ImageView;

public class PhotoActivity extends Activity {
	
	private ImageView foto;
	private static int TAKE_PICTURE = 1;
	private ImageView ivThumbnailPhoto;
	private Bitmap bitMap;
	private Button rep;
	private String latcoo, loncoo;
	//private CountDownTimer Counter;

	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		setContentView(R.layout.activity_photo);
		foto=(ImageView)findViewById(R.id.imageView1);
		
		/*
		 * En caso de implementaci�n real, las coordenadas de latcoo y loncoo deberian extraerse
		 * del mapa mediante una funci�n para que se escriban correctamente en el archivo de texto
		 * a enviar.
		 */
		latcoo="41.46771";
		loncoo="2.090766";
		
		// create intent with ACTION_IMAGE_CAPTURE action 
        Intent intent = new Intent(MediaStore.ACTION_IMAGE_CAPTURE);
        // start camera activity
        startActivityForResult(intent, TAKE_PICTURE);
     
	}
        
	
	

	@Override
    protected void onActivityResult(int requestCode, int resultCode, Intent intent) {
 
        if (requestCode == TAKE_PICTURE ){ // &&resultCode== RESULT_OK && intent != null){
            // get bundle
            Bundle extras = intent.getExtras();
           
            // get bitmap
            bitMap = (Bitmap) extras.get("data");
            foto.setImageBitmap(bitMap);
            
            String pathofBmp = Images.Media.insertImage(getContentResolver(), bitMap,"Imagen", null);
            Uri bmpUri = Uri.parse(pathofBmp);
            
            Intent i = new Intent (Intent.ACTION_SEND);
			i.setType("message/rfc822");
			i.putExtra(Intent.EXTRA_EMAIL, new String[]{"jordiyanezrios@gmail.com"});
			i.putExtra(Intent.EXTRA_SUBJECT, "FotoReporteIncidencia");
			i.putExtra(Intent.EXTRA_STREAM, bmpUri);
			i.putExtra(Intent.EXTRA_TEXT, "LAT:" + latcoo + " LON:"+ loncoo);
			startActivityForResult(Intent.createChooser(i, "Enviando email..."),2);
    	
        }
        
        else if(requestCode== 2){
        	finish();
        	
        }
        super.onActivityResult(requestCode, resultCode, intent);
    }
	
	
}
