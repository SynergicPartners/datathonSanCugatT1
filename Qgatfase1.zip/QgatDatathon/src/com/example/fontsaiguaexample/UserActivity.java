package com.example.fontsaiguaexample;

import android.app.Activity;
import android.os.Bundle;
import android.view.Menu;
import android.view.MenuItem;

public class UserActivity extends Activity {

	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		setContentView(R.layout.activity_user);
		
		/*
		 * Clase vac�a a desarrollar completamente, en este caso haria falta otra conexi�n
		 * a un csv del gobierno para mostrar los objetos canjeables. Al mismo tiempo haria
		 * falta conexi�n con facebook para conectar las im�genes a la interfaz de usuario
		 * y mostrar los amigos as� como sus civiPoints.
		 */
		
	}
}
